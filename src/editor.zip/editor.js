import React, { Component } from "react";
import { Editor } from "react-draft-wysiwyg";
import { EditorState, convertToRaw } from "draft-js";

import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import draftToHtml from "draftjs-to-html";
import HtmlParser from "react-html-parser";
import './editor.css';

export default class Editors extends Component {
  state = {
    editorState: EditorState.createEmpty(),
    array:[
      { name: 'APPLE', firstname:'apple', url: 'apple' },
                  { name: 'BANANA', firstname:'banan', url: 'banana' },
                  { text: 'CHERRY', value: 'cherry', url: 'cherry' },
                  { text: 'DURIAN', value: 'durian', url: 'durian' },
                  { text: 'EGGFRUIT', value: 'eggfruit', url: 'eggfruit' },
                  { text: 'FIG', value: 'fig', url: 'fig' },
                  { text: 'GRAPEFRUIT', value: 'grapefruit', url: 'grapefruit' },
                  { text: 'HONEYDEW', value: 'honeydew', url: 'honeydew' },
    ],
  };

  onEditorStateChange = (editorState) => {
       
    this.setState({
      editorState,

    });

    
  };


   uploadImageCallBack(file) {
    return new Promise(
      (resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://api.imgur.com/3/image');
        xhr.setRequestHeader('Authorization', 'Client-ID c166b3ccc22b789');
        const data = new FormData();
        data.append('image', file);
        xhr.send(data);
        xhr.addEventListener('load', () => {
          const response = JSON.parse(xhr.responseText);
          resolve(response);
        });
        xhr.addEventListener('error', () => {
          const error = JSON.parse(xhr.responseText);
          reject(error);
        });
      }
    );
  }



  render() {
     
    const { editorState } = this.state;
    // console.log(draftToHtml(convertToRaw(editorState.getCurrentContent())),'jhjhgjhgj');
    return (
      <div>
        <div className='editor dropup'>
        <Editor
          editorState={editorState}
          toolbarClassName="toolbarClassName "
          wrapperClassName="wrapperClassName "
          editorClassName="editorClassName"
          onEditorStateChange={this.onEditorStateChange}

        //   toolbar={{
        //     inline: {  },
        //     list: { inDropdown: true },
        //     textAlign: { inDropdown: true },
        //     link: { inDropdown: true },
        //     history: { inDropdown: true },
        //     image: { uploadCallback: this.uploadImageCallBack, alt: { present: true, mandatory: false } },
        //   }}
        
            toolbar={{
                inline: {
                    inDropdown: true,className:'inline',
                        },
                blockType: { className: 'blockType', },
                fontSize: { className: 'font' },
                list: {
                    inDropdown: true,className:'list',
                },
                textAlign: {
                    inDropdown: true,className:'textAlign',
                },
                fontFamily: { inDropdown: true,className:'fonts', },
                colorPicker: { inDropdown: true,className:'color', },
                link: {
                  inDropdown: true,className:'link',
                },
                embedded: {inDropdown: true, className: 'embed', },
                emoji: { inDropdown: true,className:'emoji', },
               
                image: {className:'img', uploadCallback: this.uploadImageCallBack, alt: { present: true, mandatory: false } },
                
              }}
              mention={{
                separator: ' ',
                trigger: '@',
                suggestions:this.state.array.map(e => {
                  return {text:e.name,value:e.firstname}
                }) ,
                
              }}
             
            
        />
        </div>
        
        <hr/>
        <p>  {HtmlParser(editorState)} </p>
      </div>
    );
  }
}      



// import React from 'react';
// import { CKEditor } from '@ckeditor/ckeditor5-react';
// import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
// import ReactHtmlParser from 'react-html-parser';
// import HtmlParser from 'react-html-parser';




// class Editor extends React.Component {
//     constructor(props){
//         super(props);
//         this.state = {
//             value:'',
//             chosenEmoji:''
//         }

//     }

//     handleChange = (e,editor) => {
//         console.log(editor.getData());//textna tpum
//         let data = editor.getData();
//         this.setState({
//             value:data,
//         })
//     }

//     onEmojiClick = (event, emojiObject) => {
//         this.setState({
//             chosenEmoji:emojiObject
//         })
//       };

//     render(){
//         return (
//             <div >
//                 <div className='editor'>
//                 <h1>Article</h1>
//                 <CKEditor
//                 editor={ClassicEditor}
//                 onChange={this.handleChange}
//                 />
//                 </div>

//                 <h1>  { ReactHtmlParser(this.state.value) }  </h1>
//                 {console.log(ReactHtmlParser(this.state.value),'l;klkl')}
//                 {console.log(HtmlParser(this.state.value))}

//                 <span>You chose: {this.state.chosenEmoji.emoji}</span>
//                 <Picker onEmojiClick={this.onEmojiClick} />

//             </div>
//         )
//     }
// }
// export default Editor;